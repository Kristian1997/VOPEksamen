/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package krikr17vopeksamen18;

import io_singleton.IO_Singleton;
import java.awt.Graphics;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Window;

/**
 *
 * @author admin
 */
public class FXMLDocumentController implements Initializable {

    private Image jugglerImages[];

    private Label label;
    @FXML
    private ImageView jugglerImageView;
    @FXML
    private Slider slider;
    @FXML
    private Label updateLabel;
    Thread t1;
    int currentImage;
    private boolean running;
    @FXML
    private TextField searchField;
    @FXML
    private TextField replaceField;
    @FXML
    private TextArea textArea;

    FileChooser filechooser;
    Window w;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        jugglerImages = new Image[4];
        String preFix = "Juggler";
        String postFix = ".jpg";
        for (int i = 0; i < jugglerImages.length; i++) {
            jugglerImages[i] = new Image(new File(preFix + i + postFix).toURI().toString());
        }
        currentImage = 0;
        jugglerImageView.setImage(jugglerImages[currentImage]);

        filechooser = new FileChooser();
        filechooser.setInitialDirectory(new File("."));

    }

    @FXML
    private void startButtonOnAction(ActionEvent event) {
        running = true;
        t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (running) {
                    try {
                        t1.sleep((int) slider.getValue());
                    } catch (InterruptedException ex) {
                        running = false;
                    }
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            updateLabel.setText("Updates :" + String.valueOf((int) slider.getValue()));
                            jugglerImageView.setImage(jugglerImages[(currentImage + 1) % jugglerImages.length]);
                        }
                    });
                    currentImage = (currentImage + 1) % jugglerImages.length;
                }
            }

        });
        t1.start();
    }

    @FXML
    private void stopButtonOnAction(ActionEvent event) {
        running = false;
        t1.interrupt();
    }

    @FXML
    private void replaceAllOnAction(ActionEvent event) {
        String search = searchField.getText();
        String replace = replaceField.getText();

        String text = textArea.getText();
        String replacetext = text.replaceAll(search, replace);
        textArea.setText(replacetext);

    }

    @FXML
    private void openFileOnAction(ActionEvent event) {
        File f = filechooser.showOpenDialog(null);
        textArea.setText(IO_Singleton.getInstance().readTextFile(f));
    }

    @FXML
    private void saveAsOnAction(ActionEvent event) {
        File f = filechooser.showOpenDialog(null);
        IO_Singleton.getInstance().saveInTextFile(textArea.getText(), f);
    }

}
