/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playing_cards;

/**
 *
 * @author admin
 */
public class Card implements Comparable<Card>{
    
    String suit;
    int face;

    public Card(String suit, int face) {
        this.suit = suit;
        this.face = face;
    }
   

    public String toString() {
        return (suit + " " + face); 
    }
    

    public String getSuit() {
        return suit;
    }

    public int getFace() {
        return face;
    }

    @Override
    public int compareTo(Card o) {
        int r = this.getSuit().compareTo(o.suit);
        if(r == 0) {
            r = this.getFace() - o.getFace();
        }
        return r;
    }


    
}
