/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playing_cards;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class CardPlayer {

    String name;
    int numberOfCards;
    Card[] cards;

    public CardPlayer(String name, int numberOfCards) {
        this.name = name;
        this.numberOfCards = numberOfCards;
        cards = new Card[numberOfCards];
    }

    @Override
    public String toString() {
        return Arrays.toString(cards);
    }

    public void addCardToHand(Card card) throws Exception {

        if (cards[cards.length -1] != null) {
            throw new ArrayIndexOutOfBoundsException("Too many cards");
        }

        try {
            for (int i = 0; i < cards.length; i++) {
                if (cards[i] == null) {
                        cards[i] = card;
                        break;
                    }
                }
            
            Arrays.sort(cards);

        } catch (ArrayIndexOutOfBoundsException ex) {
            Logger.getLogger(CardPlayer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
