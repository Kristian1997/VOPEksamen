package playing_cards;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Udleveret kodeskelet til VOP Eksamen F18
 *
 * @author erso
 */
public class DeckOfCards implements CardInterface {

    List<Card> deck;

    public DeckOfCards() {
        this.deck = new LinkedList<>();
        int cardnumber = 0;
        int cardface = 0;
        for (int i = 0; i < NUMBER_OF_CARDS; i++) {
            this.deck.add(new Card(SUITS[cardface], cardnumber));
            cardnumber ++;
            if (cardnumber == 13) {
                cardnumber = 0;
                cardface++;
            }

        }
    }
        
    public void shuffleCards() {
        Collections.shuffle(deck);
        System.out.println(deck);
    }

    public Card pickCard(){
        Card c = deck.get(0);
        deck.remove(0);
        return c;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        DeckOfCards deck = new DeckOfCards();
        deck.shuffleCards();
        deck.pickCard();


        CardPlayer playerA = new CardPlayer("Player A", CardInterface.SIZE_OF_HAND);
        CardPlayer playerB = new CardPlayer("Player B", CardInterface.SIZE_OF_HAND);
        for(int i = 0; i < CardInterface.SIZE_OF_HAND; i++){
            try {
                playerA.addCardToHand(deck.pickCard());
                playerB.addCardToHand(deck.pickCard());
            } catch (Exception ex) {
                Logger.getLogger(DeckOfCards.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println(playerA);
        System.out.println(playerB);
    }

}
