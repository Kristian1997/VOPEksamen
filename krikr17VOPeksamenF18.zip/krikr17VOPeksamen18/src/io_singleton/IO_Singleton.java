package io_singleton;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Udleveret kodeskelet til VOP Eksamen F18
 *
 * @author erso
 */
public class IO_Singleton {

    private static IO_Singleton instance;
    PrintWriter output;

    public static IO_Singleton getInstance() {
        if (instance == null) {
            instance = new IO_Singleton();
        }
        return instance;
    }

    // public methodes:
    public String readTextFile(File inFile) {
        String text = "";
        try (Scanner scanner = new Scanner(inFile, "UTF-8")) {

            while (scanner.hasNextLine()) {
                text += scanner.nextLine();
            }

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        return text;
    }

    public void saveInTextFile(String text, File outFile) {
         try {
            output = new PrintWriter(outFile);
            output.println(text);
            output.flush();
        } catch (IOException ex) {
            System.out.println("could not log data");
        } finally {
            output.close();
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        File inFile = new File("HelloWorld.txt");

        String original = IO_Singleton.getInstance().readTextFile(inFile);
        System.out.println("Original:\n" + original);

        String replaced = original.replaceAll("Hello", "Goodbye");
        System.out.println("Replaced:\n" + replaced);

        IO_Singleton.getInstance().saveInTextFile(replaced, new File("GoodbyeWorld.txt"));

    }

}
